var checksum = require('../../model/checksum');

module.exports = function(app) {

    app.get('/pgredirect', function(req, res) {
        console.log("in pgdirect start");
        //console.log("--------testtxnjs----", JSON.stringify(req));
        res.render('pgredirect.ejs');
    });
};
//vidisha