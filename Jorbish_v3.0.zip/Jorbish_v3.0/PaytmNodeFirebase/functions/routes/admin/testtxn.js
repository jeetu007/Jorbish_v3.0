var checksum = require('../../model/checksum');
var config = require('../../config/config');

module.exports = function(app) {

    app.get('/testtxn', function(req, res) {
        console.log("Transaction initiated...");
        if (isNaN(req.query.TXN_AMOUNT) || req.query.TXN_AMOUNT < 1 || !req.query.ORDER_ID || req.query.ORDER_ID == "" || !req.query.CALLBACK_URL || req.query.CALLBACK_URL == "") {
            //config.ORDER_ID = 'ORDER_' + Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000;
            res.render('testtxn.ejs', { 'config': config, valid: false });
        } else {
            config.ORDER_ID = req.query.ORDER_ID
            config.CUST_ID = req.query.CUST_ID
            config.MOBILE_NO = req.query.MOBILE_NO
            config.EMAIL = req.query.EMAIL
            config.TXN_AMOUNT = req.query.TXN_AMOUNT
            config.REDIRECT_URL = req.query.CALLBACK_URL
            res.render('testtxn.ejs', { 'config': config, valid: true });
        }
    });

    app.post('/testtxn', function(req, res) {
        console.log("Transaction started...");
        var paramlist = req.body;
        var paramarray = new Array();

        for (name in paramlist) {
            if (name == 'PAYTM_MERCHANT_KEY') {
                var PAYTM_MERCHANT_KEY = paramlist[name];
            } else {
                paramarray[name] = paramlist[name];
            }
        }
        checksum.genchecksum(paramarray, PAYTM_MERCHANT_KEY, function(err, result) { res.render('pgredirect.ejs', { 'restdata': result, 'paytmFinalUrl': config.PAYTM_FINAL_URL }); });
    });
};