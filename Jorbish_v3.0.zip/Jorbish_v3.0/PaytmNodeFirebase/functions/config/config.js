'use strict';

var PAYTM_STAG_URL = 'https://securegw-stage.paytm.in/theia/processTransaction';
var PAYTM_PROD_URL = 'https://securegw.paytm.in/theia/processTransaction';
var MID = 'GEyCeV76589235773125';
var PAYTM_ENVIORMENT = 'TEST'; // PROD FOR PRODUCTION
var PAYTM_MERCHANT_KEY = '3uSINJ8vVIqiPeVY';
var WEBSITE = 'WEBSTAGING';
var CHANNEL_ID = 'WEB';
var INDUSTRY_TYPE_ID = 'Retail';
var ORDER_ID = '';
var PAYTM_FINAL_URL = '';
var CALLBACK_URL = 'http://localhost:5000/jorbish-79a9b/us-central1/payment/response'
if (PAYTM_ENVIORMENT == 'TEST') {
    PAYTM_FINAL_URL = PAYTM_STAG_URL
} else {
    PAYTM_FINAL_URL = PAYTM_PROD_URL
}

module.exports = {
    ORDER_ID: ORDER_ID,
    MID: MID,
    PAYTM_MERCHANT_KEY: PAYTM_MERCHANT_KEY,
    PAYTM_FINAL_URL: PAYTM_FINAL_URL,
    CALLBACK_URL: CALLBACK_URL,
    WEBSITE: WEBSITE,
    CHANNEL_ID: CHANNEL_ID,
    INDUSTRY_TYPE_ID: INDUSTRY_TYPE_ID,
    REDIRECT_URL: ''
};