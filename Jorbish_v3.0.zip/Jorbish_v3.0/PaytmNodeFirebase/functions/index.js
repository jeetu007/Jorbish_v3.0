const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

const cors = require("cors")
const express = require("express")
const redirect = require("express-redirect");
const router = express.Router();
const bodyParser = require('body-parser');

const app = express();
redirect(app);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(router);
require('./routes/admin/testtxn')(app);
require('./routes/admin/pgredirect')(app);
require('./routes/admin/response')(app);
app.use(express.static(__dirname + '/public'));
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');


/* Express with CORS & automatic trailing '/' solution */
app.use(cors({ origin: true }))
app.get("*", (request, response) => {
    response.send("Paytm Payment Gateway....")
})

// not as clean, but a better endpoint to consume
const payment = functions.https.onRequest((request, response) => {
    if (!request.path) { request.url = `/${request.url}` }
    return app(request, response)
})

module.exports = { payment }