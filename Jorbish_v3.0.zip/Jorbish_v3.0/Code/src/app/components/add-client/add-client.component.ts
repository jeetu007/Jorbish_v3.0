import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

import { AuthService } from '../../services/auth/auth.service';
import { ClientService } from '../../services/client/client.service';
import { FirebaseService } from '../../services/superadmin/firebase.service';

import * as XLSX from 'ts-xlsx';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css']
})
export class AddClientComponent implements OnInit {

  clients;
  clientDetail: any = {};
  client: any = { clientId: '', billingId: '', layoutImage: '', company: {} };
  selectedClient: any;
  employeeList: any;
  contactPersonList: any = [];
  deviceList: any;
  arrayBuffer: any;

  // edit functionalities
  overrideField: boolean = false;
  overriddenContactPersons: any;
  previousContactPersons: any;
  overrideDeviceField: boolean = false;
  overriddenDevices: any;
  previousDevices: any;
  overrideEmployeeField: boolean = false;
  overriddenEmployees: any;
  previousEmployees: any;

  public addClientForm: FormGroup;

  billing: any = {};
  isWebCamActivated: boolean = false;
  selectedCenterId: any;
  public webcamImage: WebcamImage = null;
  private trigger: Subject<void> = new Subject<void>();
  currentContactPerson: any = {};
  public isValidEmail : boolean = true;

  bookingDetails : any;

  constructor(private ngFireStore: AngularFirestore, private authService: AuthService, private firebaseService: FirebaseService,
    private clientService: ClientService, private formBuilder: FormBuilder,
     public router: Router, private route: ActivatedRoute,private toastr: ToastrService) {
    this.addClientForm = formBuilder.group({
      companyName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(35), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      PAN: ['', Validators.compose([Validators.minLength(10), Validators.maxLength(10), Validators.pattern('[a-zA-Z0-9]*'), Validators.required])],
      contact: ['', Validators.compose([Validators.minLength(10), Validators.maxLength(10), Validators.pattern('[0-9]*'), Validators.required])],
      email: ['', Validators.compose([Validators.maxLength(60),Validators.required])],
      GSTN: ['', Validators.compose([Validators.minLength(15), Validators.maxLength(15), Validators.pattern('[a-zA-Z0-9]*'), Validators.required])],
      address: ['', Validators.compose([Validators.maxLength(120), Validators.required])],
      depositAmount: ['', Validators.compose([Validators.maxLength(10), Validators.required])],
      lockIn: ['', Validators.compose([Validators.maxLength(10), Validators.required])],
      noticePeriod: ['', Validators.compose([Validators.maxLength(200), Validators.required])]
    });

    this.route.params.subscribe(params => {
      this.selectedCenterId = params.centerId;
    });
  }

  ngOnInit() {
    this.getClientList();
    this.bookingDetails = this.clientService.getBookingDetail();
  }

  getClientList() {
    this.ngFireStore.collection("clients").snapshotChanges().pipe(
      map(changes =>
        changes.map(action => {
          const data = action.payload.doc.data() as any;
          const id = action.payload.doc.id;
          return { id, ...data };
        })
      )
    ).subscribe(response => {
      this.clients = response;
      console.log("clientList  =>", this.clients);
    });
  }

  // if file is selected then take the list of contactPersons from the file or edit the already
  // existing contactPersons for updation
  editClient(client) {
    this.selectedClient = client;
  }

  addEmployees(event) {
    let file = event.target.files[0];
    this.getUploadedFileInJsonFormat(file).then(res => {
      this.employeeList = res;
      console.log("empList ==> ", this.employeeList);
    }).catch(err => {
      console.log(err);
    });
  }

  getDevices(event) {
    let file = event.target.files[0];
    this.getUploadedFileInJsonFormat(file).then(res => {
      this.deviceList = res;
      console.log(this.deviceList);
    }).catch(err => {
      console.log(err);
    });
  }

  saveEmployeeAsContactPerson(user) {
    console.log(user);
    this.isWebCamActivated = false;
    let existingUser = false;
    if (this.contactPersonList.length > 0) {
      for (let i = 0; i < this.contactPersonList.length; i++) {
        if (user.email === this.contactPersonList[i].email) {
          this.toastr.error("Already added !");
          existingUser = true;
        }
      }
    }
    if (!existingUser) {
      this.contactPersonList.push(user);
    }
  }

  captureContactPersonImage(event) {
    this.isWebCamActivated = true;
  }

  public triggerSnapshot(user): void {
    this.currentContactPerson = user;
    this.trigger.next();
  }

  public handleInitError(error: WebcamInitError): void {
    console.log("Camera Error ==>", error);
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public handleImage(webcamImage: WebcamImage): void {
    this.webcamImage = webcamImage;
    let userIndex = this.contactPersonList.indexOf(this.currentContactPerson);
    this.contactPersonList[userIndex].picture = this.webcamImage['_imageAsDataUrl'];
    this.isWebCamActivated = false;
    console.log(this.contactPersonList);
  }

  cancelWebCam() {
    this.isWebCamActivated = false;
  }

  removeContactPerson(user) {
    let userIndex = this.contactPersonList.indexOf(user);
    this.contactPersonList.splice(userIndex, 1);
    this.toastr.error("Removed !");
  }

  getUploadedFileInJsonFormat(file) {
    return new Promise((resolve, reject) => {
      try {
        let fileReader = new FileReader();
        fileReader.onload = (e) => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();
          for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
          var bstr = arr.join("");
          var workbook = XLSX.read(bstr, { type: "binary" });
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          resolve(XLSX.utils.sheet_to_json(worksheet, { raw: true }));
        }
        fileReader.readAsArrayBuffer(file);
      } catch (error) {
        reject(error);
      }
    });
  }

  getClients() {
    this.ngFireStore.collection("clients").valueChanges().subscribe(res => {
      this.clients = res;
      console.log(this.clients);
    }, err => {
      console.log(err);
    });
  }

  saveClient() {
    const clientId = this.ngFireStore.createId();
    this.client['clientId'] = clientId;
    this.client['billingId'] = "";
    this.client['layoutImage'] = "";
    this.client['company'] = {};
    this.client['company']['GSTN'] = this.addClientForm.value.GSTN;
    this.client['company']['companyName'] = this.addClientForm.value.companyName;
    this.client['company']['PAN'] = this.addClientForm.value.PAN;
    this.client['company']['address'] = this.addClientForm.value.address;
    this.client['company']['contactPersons'] = this.contactPersonList;
    this.client['company']['employees'] = this.employeeList;
    this.client['company']['devices'] = this.deviceList;
    this.clientService.saveClient(clientId, this.client);
    this.saveBookingDetail(clientId);
    this.addClientToCenter(this.client);
  }

  saveBookingDetail(clientId) {
    // let bookingDetail = JSON.parse(localStorage.getItem("bookingDetail"));
    let billingInfo = {};
    billingInfo['companyName'] = this.addClientForm.value.companyName;
    billingInfo['depositAmount'] = parseInt(this.addClientForm.value.depositAmount);
    billingInfo['lockIn'] = parseInt(this.addClientForm.value.lockIn);
    billingInfo['noticePeriod'] = parseInt(this.addClientForm.value.noticePeriod);
    billingInfo['email'] = this.addClientForm.value.email;
    billingInfo['contact'] = this.addClientForm.value.contact;
    billingInfo['clientId'] = clientId;
    billingInfo['centerId'] = this.selectedCenterId;
    billingInfo['bookingDetail'] = this.bookingDetails;
    billingInfo['bookingStatus'] = "started";
    console.log("booking-->", billingInfo);
    this.clientService.saveBillingInfo(billingInfo);
    this.router.navigate(['book-center']);
  }

  addClientToCenter(client) {
    this.firebaseService.addClientToCenter(this.selectedCenterId, client).then(res => {
      console.log("ClientAddedToCenter==>", res);
      this.addClientForm.reset();
      this.bookingDetails = [];
    }).catch(err => {
      console.log(err);
      this.addClientForm.reset();
      this.bookingDetails = [];
    });
  }

  checkEmailValidation(email){
    console.log(email)
    if(this.validateEmail(email)){
       this.isValidEmail = true;
       console.log(this.isValidEmail)
    } else{
      this.isValidEmail = false;
      console.log(this.isValidEmail)
    }
  }

  validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }

  // edit functionalities
  overrideContacts(event) {
    let file = event.target.files[0];
    this.getUploadedFileInJsonFormat(file).then(res => {
      this.overriddenContactPersons = res;
      console.log("overideContacts-->", this.overriddenContactPersons);
      this.overrideField = true;
      this.previousContactPersons = this.selectedClient.company.contactPersons;
      this.selectedClient.company.contactPersons = this.overriddenContactPersons;
      console.log(this.selectedClient);
    }).catch(err => {
      console.log(err);
    });

  }



}
