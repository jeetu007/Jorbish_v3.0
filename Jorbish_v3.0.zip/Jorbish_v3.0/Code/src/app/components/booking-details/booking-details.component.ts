import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

import { AuthService } from "../../services/auth/auth.service";
import { BillingService } from "../../services/billing/billing.service";

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.css']
})
export class BookingDetailsComponent implements OnInit {

  currDate = new Date();
  totalTime: any;

  totalAmount = 0;

  bookingInfo = [];
  viewSelectedBooking: any;

  constructor(public billingService: BillingService, public router: Router, public authService: AuthService) { }

  ngOnInit() {
    this.loadBokingDetails();
  }

  loadBokingDetails() {
    let billing_snapshot = this.billingService.getBill();
    billing_snapshot.snapshotChanges().subscribe(response => {
      this.bookingInfo = [];
      
      response.forEach(res => {
        this.bookingInfo.push(res.payload.doc.data());
      });
    });
  }

  viewBooking(booking) {
    this.viewSelectedBooking = booking;
    let bookingDetail = booking.bookingDetail;

    for (let book in bookingDetail) {
      let space_price = this.billingService.getPrice(bookingDetail[book].priceId);
      space_price.subscribe(res => {
        let priceData = res.data();
        bookingDetail[book]["costPrice"] = priceData[bookingDetail[book].timeUnit];
      })
    }

  }

  totalTimeCalculation(event) {
    let endDay = event.target.value.substring(8, 10);
    let startDay = this.viewSelectedBooking.bookingDetail[0].startTime.substring(8, 10);

    this.totalTime = endDay - startDay;
    let bookingDetail = this.viewSelectedBooking.bookingDetail;

    for (let book in bookingDetail) {
      bookingDetail[book].endTime = event.target.value;
      bookingDetail[book]["totalTime"] = this.totalTime;
      if (bookingDetail[book].timeUnit == "monthly") {
        this.totalAmount += bookingDetail[book]["costPrice"] * this.totalTime / 30;
        bookingDetail[book].totalTime = endDay - startDay;
      }
      else if (bookingDetail[book].timeUnit == "daily") {
        this.totalAmount += bookingDetail[book]["costPrice"] * this.totalTime;
        bookingDetail[book].totalTime = endDay - startDay;
      }
    }
    this.viewSelectedBooking.bookingDetail = bookingDetail;
    this.viewSelectedBooking["totalAmount"] = this.totalAmount;

    this.billingService.updateBooking(this.viewSelectedBooking);

    // localStorage.setItem("BookingInvoice",JSON.stringify(this.viewSelectedBooking));

  }

  closeModal() {
    this.totalAmount = 0;
  }

  validateObject(obj) {
    return (obj != undefined && Object.keys(obj).length != 0);
  }



  logout($event) {
    this.authService.signOut().then(res => {
      this.router.navigate(['login']);
    }).catch(err => {
      this.router.navigate(['login']);
    });
  }//logout(-)

}
