import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from "../../services/auth/auth.service";
@Component({
  selector: 'app-access-denied',
  templateUrl: './access-denied.component.html',
  styleUrls: ['./access-denied.component.css']
})
export class AccessDeniedComponent implements OnInit {

  constructor(private router: Router, public authService:AuthService) { }

  ngOnInit() {
  }

  logout() {
    this.authService.signOut().then(res => {
      console.log("res");
      
      this.router.navigate(['login']);
    }).catch(err => {
      console.log("err");

      this.router.navigate(['login']);
    });
  }

}
