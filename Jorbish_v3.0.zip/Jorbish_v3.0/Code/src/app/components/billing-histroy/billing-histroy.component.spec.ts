import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingHistroyComponent } from './billing-histroy.component';

describe('BillingHistroyComponent', () => {
  let component: BillingHistroyComponent;
  let fixture: ComponentFixture<BillingHistroyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingHistroyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingHistroyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
