import { Component, OnInit } from '@angular/core';
import { BillingService } from "../../services/billing/billing.service";
import { AngularFirestore } from '@angular/fire/firestore';
import { Router } from "@angular/router";



import { from } from 'rxjs';

@Component({
  selector: 'app-billing-histroy',
  templateUrl: './billing-histroy.component.html',
  styleUrls: ['./billing-histroy.component.css']
})
export class BillingHistroyComponent implements OnInit {

  billingHistroy:any;
  bookingDetails:any;


  constructor(private billing:BillingService,private firestore: AngularFirestore) { }

  ngOnInit() {
      this.firestore.collection('billingHistory').valueChanges().subscribe(res => {
       this.billingHistroy=res;
       console.log('resource come from ==>',this.billingHistroy);
      //  for(var i =0;i>=this.billingHistroy.length;i++){
      //  this.bookingDetails= this.billingHistroy[i].bookingDetail;
      //  console.log('billingHistroy ==>',this.bookingDetails)
      //  }
      }, err => {
       console.log(err)
       
      });
    }
  
    showSelectedBilling(bill) {
      console.log('billingHistroy ==>',bill.bookingDetail)
      this.bookingDetails=bill.bookingDetail;
    }

  }


