import { Component, EventEmitter, OnInit, Input, OnChanges, OnDestroy } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

import { UserServiceService } from "../../services/user-service/user-service.service";
import { AuthService } from "../../services/auth/auth.service";
import { map } from 'rxjs/operators';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-user-operation',
  templateUrl: './user-operation.component.html',
  styleUrls: ['./user-operation.component.css']
})
export class UserOperationComponent implements OnInit {

  userModel: any;
  userList: any = [];
  isModel: boolean = false;
  editBtn: boolean
  currentUser: any
  constructor(private afs: AngularFirestore, private userService: UserServiceService, private authService: AuthService,
    private router: Router) {
    this.getUsers();
  }
  ngOnInit() { }

  getUserModel() {
    return this.userModel
  }

  getUsers() {
    this.userService.getUsers().subscribe(res => {
      console.log(res);
      if (res) {
        this.authService.user$.subscribe(userSubscribe => {
          this.userList = res.filter(user => user.uid !== userSubscribe.uid);
          console.log(this.userList);
          if (userSubscribe.role.admin) {
            for (let user of this.userList) {
              if (user.role.admin) {
                this.userList.splice(this.userList.indexOf(user), 1);
              }
            }
            this.userList = this.userList.filter(user => user.center_ref === userSubscribe.center_ref)
          }
          console.log(this.userList);
        })
      }
    }, err => {
      console.log("err >> ", err);
    })
  }

  ngOnDestroy(): void {
  }

  doEdit(event, user) {
    event.preventDefault()
    this.editBtn = true;
    this.userModel = user;
    this.isModel = true
    this.editBtn = true
  }

  doDelete(event, model) {
    event.preventDefault()
    // console.log("... ", model);
    this.authService.user$.subscribe(user => {
      if (user.role.superadmin || user.role.admin) {
        var result = confirm("Want to delete?");
        if (result) {
          // console.log("result >> ", result);
          this.userService.delete(model)
        }
      }
    })
  }
  addBtn() {
    console.log(">> ", this.editBtn);
    if (this.editBtn) {
      this.editBtn = false;
      this.userModel = {};
    }
    this.isModel = true

  }
  closeBtn() {
    this.isModel = false;
  }

  logout($event) {
    this.authService.signOut().then(res => {
      this.router.navigate(['login']);
    }).catch(err => {
      this.router.navigate(['login']);
    });
  }//logout(-)
}
