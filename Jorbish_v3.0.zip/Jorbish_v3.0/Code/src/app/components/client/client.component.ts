import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { AuthService } from '../../services/auth/auth.service';
import { ClientService } from '../../services/client/client.service';
import * as XLSX from 'ts-xlsx';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  clients;
  clientDetail: any = {};
  client: any = { clientId: '', billingId: '', layoutImage: '', company: {} };
  selectedClient: any;
  employeeList: any;
  contactPersonList: any = [];
  deviceList: any;
  arrayBuffer: any;

  // edit functionalities
  overrideContactField: boolean = false;
  overriddenContactPersons: any;
  previousContactPersons: any;
  overrideDeviceField: boolean = false;
  overriddenDevices: any;
  previousDevices: any;
  overrideEmployeeField: boolean = false;
  overriddenEmployees: any;
  previousEmployees: any;
  currentUser:any;
  
  public addClientForm: FormGroup;

  isWebCamActivated: boolean = false;
  public webcamImage: WebcamImage = null;
  private trigger: Subject<void> = new Subject<void>();
  currentContactPerson: any = {};

  constructor(private ngFireStore: AngularFirestore, private authService: AuthService,
    private clientService: ClientService, private formBuilder: FormBuilder, public router: Router) {
    this.addClientForm = formBuilder.group({
      companyName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(35), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      PAN: ['', Validators.compose([Validators.minLength(10), Validators.maxLength(10), Validators.pattern('[a-zA-Z0-9]*'), Validators.required])],
      GSTN: ['', Validators.compose([Validators.minLength(15), Validators.maxLength(15), Validators.pattern('[a-zA-Z0-9]*'), Validators.required])],
      address: ['', Validators.compose([Validators.maxLength(120), Validators.required])]
    });
  }

  ngOnInit() {
    this.getClientList();
    let user = this.authService.user$.subscribe(user => {
      this.currentUser = user;
    }, err => {
      console.log("Auth User Err ->", err);
    })
  }

  getClientList() {
    this.ngFireStore.collection("clients").snapshotChanges().pipe(
      map(changes =>
        changes.map(action => {
          const data = action.payload.doc.data() as any;
          const id = action.payload.doc.id;
          return { id, ...data };
        })
      )
    ).subscribe(response => {
      this.clients = response;
      console.log("clientList  =>", this.clients);
    });
  }

  // if file is selected then take the list of contactPersons from the file or edit the already
  // existing contactPersons for updation
  editClient(client) {
    this.selectedClient = client;
  }

  addEmployees(event) {
    let file = event.target.files[0];
    this.getUploadedFileInJsonFormat(file).then(res => {
      this.employeeList = res;
      console.log("empList ==> ", this.employeeList);
    }).catch(err => {
      console.log(err);
    });
  }

  getDevices(event) {
    let file = event.target.files[0];
    this.getUploadedFileInJsonFormat(file).then(res => {
      this.deviceList = res;
      console.log(this.deviceList);
    }).catch(err => {
      console.log(err);
    });
  }

  goToAddClient() {
    this.router.navigate(['book-center']);
  }

  saveEmployeeAsContactPerson(user) {
    console.log(user);
    if (this.overrideContactField) {
      let existingUser = false;
      if (this.overriddenContactPersons.length > 0) {
        for (let i = 0; i < this.overriddenContactPersons.length; i++) {
          if (user.email === this.overriddenContactPersons[i].email) {
            console.log("Already exists..");
            existingUser = true;
          }
        }
      }
      if (!existingUser) {
        this.overriddenContactPersons.push(user);
      }
    } else {
      let existingUser = false;
      if (this.selectedClient.company.contactPersons.length > 0) {
        for (let i = 0; i < this.selectedClient.company.contactPersons.length; i++) {
          if (user.email === this.selectedClient.company.contactPersons[i].email) {
            console.log("Already exists..");
            existingUser = true;
          }
        }
      }
      if (!existingUser) {
        this.selectedClient.company.contactPersons.push(user);
      }
    }
  }

  captureContactPersonImage(event) {
    this.isWebCamActivated = true;
  }

  public triggerSnapshot(user): void {
    this.currentContactPerson = user;
    this.trigger.next();
  }

  public handleInitError(error: WebcamInitError): void {
    console.log("Camera Error ==>", error);
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  public handleImage(webcamImage: WebcamImage): void {
    this.webcamImage = webcamImage;
    if (this.overrideEmployeeField) {

    } else {
      let userIndex = this.selectedClient.company.contactPersons.indexOf(this.currentContactPerson);
      this.selectedClient.company.contactPersons[userIndex].picture = this.webcamImage['_imageAsDataUrl'];
      console.log(this.selectedClient.company.contactPersons);
    }
    this.isWebCamActivated = false;
  }

  cancelWebCam() {
    this.isWebCamActivated = false;
  }

  removeContactPerson(user) {
    console.log("Removing...", user);
    if (this.overrideContactField) {
      let userIndex = this.overriddenContactPersons.indexOf(user);
      this.overriddenContactPersons.splice(userIndex, 1);
    } else {
      let userIndex = this.selectedClient.company.contactPersons.indexOf(user);
      this.selectedClient.company.contactPersons.splice(userIndex, 1);
    }
  }

  getUploadedFileInJsonFormat(file) {
    return new Promise((resolve, reject) => {
      try {
        let fileReader = new FileReader();
        fileReader.onload = (e) => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();
          for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
          var bstr = arr.join("");
          var workbook = XLSX.read(bstr, { type: "binary" });
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          resolve(XLSX.utils.sheet_to_json(worksheet, { raw: true }));
        }
        fileReader.readAsArrayBuffer(file);
      } catch (error) {
        reject(error);
      }
    });
  }

  updateEmployee(selectedClient, user, name, mobile) {
    console.log("Id->", selectedClient.id);
    selectedClient.company.employees[selectedClient.company.employees.indexOf(user)].name = name;
    selectedClient.company.employees[selectedClient.company.employees.indexOf(user)].mobile = mobile;
    console.log("updated value =>", selectedClient.company.employees);

  }

  updateContactPersons(selectedClient, user, name, mobile) {
    console.log("Id->", selectedClient.id);
    selectedClient.company.contactPersons[selectedClient.company.contactPersons.indexOf(user)].name = name;
    selectedClient.company.contactPersons[selectedClient.company.contactPersons.indexOf(user)].mobile = mobile;
    console.log("updated value =>", selectedClient.company.contactPersons);
  }

  getClients() {
    this.ngFireStore.collection("clients").valueChanges().subscribe(res => {
      this.clients = res;
      console.log(this.clients);
    }, err => {
      console.log(err);
    });
  }

  updateClient() {
    this.clientService.updateClient(this.selectedClient);
  }

  saveClient() {
    const clientId = this.ngFireStore.createId();
    console.log(this.clientDetail);
    this.client['clientId'] = clientId;
    this.client['billingId'] = "";
    this.client['layoutImage'] = "";
    this.client['company'] = {};
    this.client['company']['GSTN'] = this.addClientForm.value.GSTN;
    this.client['company']['companyName'] = this.addClientForm.value.companyName;
    this.client['company']['PAN'] = this.addClientForm.value.PAN;
    this.client['company']['address'] = this.addClientForm.value.address;
    this.client['company']['contactPersons'] = this.contactPersonList;
    this.client['company']['employees'] = this.employeeList;
    this.client['company']['devices'] = this.deviceList;
    console.log(this.client);
    this.clientService.saveClient(clientId, this.client);
  }

  // edit functionalities
  overrideContacts(event) {
    let file = event.target.files[0];
    this.getUploadedFileInJsonFormat(file).then(res => {
      this.overriddenContactPersons = res;
      console.log("overideContacts-->", this.overriddenContactPersons);
      this.overrideContactField = true;
      this.previousContactPersons = this.selectedClient.company.contactPersons;
      this.selectedClient.company.contactPersons = this.overriddenContactPersons;
      console.log(this.selectedClient);
    }).catch(err => {
      console.log(err);
    });

  }

  undoExcelFileUpload() {
    this.overrideContactField = false;
    this.selectedClient.company.contactPersons = this.previousContactPersons;
    console.log("undo contact-->", this.selectedClient.company.contactPersons);
  }

  overrideDevices(event) {
    let file = event.target.files[0];
    this.getUploadedFileInJsonFormat(file).then(res => {
      this.overriddenDevices = res;
      console.log("overideDevices-->", this.overriddenDevices);
      this.overrideDeviceField = true;
      this.previousDevices = this.selectedClient.company.devices;
      this.selectedClient.company.devices = this.overriddenDevices;
      console.log(this.selectedClient);
    }).catch(err => {
      console.log(err);
    });
  }

  undoDeviceUpload() {
    this.overrideDeviceField = false;
    this.selectedClient.company.devices = this.previousDevices;
  }

  overrideEmployees(event) {
    let file = event.target.files[0];
    this.getUploadedFileInJsonFormat(file).then(res => {
      this.overriddenEmployees = res;
      console.log("overideDevices-->", this.overriddenEmployees);
      this.overrideEmployeeField = true;
      this.previousEmployees = this.selectedClient.company.employees;
      this.selectedClient.company.employees = this.overriddenEmployees;
      this.previousContactPersons = this.selectedClient.company.contactPersons;
      this.selectedClient.company.contactPersons = [];
      this.overriddenContactPersons = [];
      console.log(this.selectedClient);
    }).catch(err => {
      console.log(err);
    });
  }

  undoEmployeeUpload() {
    this.overrideEmployeeField = false;
    this.overrideContactField = false;
    this.selectedClient.company.employees = this.previousEmployees;
    this.selectedClient.company.contactPersons = this.previousContactPersons;
    console.log("undo emp", this.selectedClient.company.contactPersons);
  }

}
