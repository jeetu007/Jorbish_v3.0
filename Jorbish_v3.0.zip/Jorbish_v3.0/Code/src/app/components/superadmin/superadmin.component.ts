import { Component, OnInit } from '@angular/core';
import { FirebaseService } from '../../services/superadmin/firebase.service'
import * as XLSX from 'ts-xlsx';
import { AuthService } from '../../services/auth/auth.service';
import {  Router} from '@angular/router';

@Component({
  selector: 'app-superadmin',
  templateUrl: './superadmin.component.html',
  styleUrls: ['./superadmin.component.css']
})
export class SuperadminComponent implements OnInit {

  public arrayBuffer: any;
  public file: File;
  public layout:any = {
    centers:null,
    selectedCenter:null,
    newCenter:{
      centerId:null,
      contact:{contactPerson:null,contactNumber:null,contactEmail:null},
      address: { addressLine1: null, addressLine2: null, area: null, city: null, state: null, country:null,pincode:null}
    },
    cabin:{
      cabinId:null,
      name:null,
      capacity:null,
      dimension:null,
      info:null,
      status:null,
      price: {
        minutes: null,
        hourly: null,
        daily: null,
        monthly: null
      }
    },
    desk: {
      deskId: null,
      type : null,
      dimension: null,
      info: null,
      status: null,
      price: {
        minutes: null,
        hourly: null,
        daily: null,
        monthly: null
      }
    },
    conferenceRoom : {
      conferenceId: null,
      capacity: null,
      dimension: null,
      info: null,
      status: null,
      price: {
        minutes: null,
        hourly: null,
        daily: null,
        monthly: null
      }
    },
    trainingRoom : {
      trainingId: null,
      capacity: null,
      dimension: null,
      info: null,
      status: null,
      price: {
        minutes: null,
        hourly: null,
        daily: null,
        monthly: null
      }
    }

  }

  constructor(private firebaseService:FirebaseService, private authService: AuthService,
    private router: Router) { 

  }

  ngOnInit() {
    this.getCenters();  
  }

  logout($event){
    this.authService.signOut().then(res => {
      this.router.navigate(['login']);
    }).catch(err => {
      this.router.navigate(['login']);
    });
  }//logout(-)

  addObject(type) {
    if(type == 'center') {
      this.layout.newCenter = {
        centerId: null,
        contact: { contactPerson: null, contactNumber: null, contactEmail: null },
        address: { addressLine1: null, addressLine2: null, area_tags: [],area: null, city: null, state: null, country: null, pincode: null }
      }
    } else if (type == 'cabin') {
      this.layout.cabin = {
        cabinId: null,
        name: null,
        capacity: null,
        dimension: null,
        info: null,
        status: null,
        price: {
          minutes:null,
          hourly:null,
          daily:null,
          monthly:null
        }
      }
    } else if (type == 'desk') {
      this.layout.cabin = {
        deskId: null,
        type: null,
        dimension: null,
        info: null,
        status: null,
        price: {
          minutes: null,
          hourly: null,
          daily: null,
          monthly: null
        }
      }
    } else if (type == 'conferenceRoom') {
      this.layout.conferenceRoom = {
        conferenceId: null,
        capacity: null,
        dimension: null,
        info: null,
        status: null,
        price: {
          minutes: null,
          hourly: null,
          daily: null,
          monthly: null
        }
      }
    } else if (type == 'trainingRoom') {
      this.layout.trainingRoom = {
        trainingId: null,
        capacity: null,
        dimension: null,
        info: null,
        status: null,
        price: {
          minutes: null,
          hourly: null,
          daily: null,
          monthly: null
        }
      }
    }
  }


  getCenterCollectionByType(type) {
    if (!this.layout.selectedCenter)
      alert('Sorry! No center is selected')
    else {
      this.firebaseService.getCenterCollectionByType(this.layout.selectedCenter, type)
      .then(res => {
        this.layout.selectedCenter[type] = res;
        console.log(this.layout.selectedCenter[type])
      }).catch(error => {
        console.log(error)
        alert('Something went wrong!')
      })
    }
  }


  deleteObject(type, id) {
    if(type == 'center') {
      if (!this.layout.selectedCenter)
        alert('Sorry! No center is selected')
      else {
        if (confirm("Are you really want to delete center?")) {
          this.firebaseService.deleteCenter(this.layout.selectedCenter)
            .then(res => {
              alert('Center has been deleted successfully!')
              for (let i = 0; i < this.layout.centers.length; i++) {
                if (this.layout.selectedCenter.id == this.layout.centers[i].id) {
                  this.layout.centers.splice(i, 1);
                  this.layout.selectedCenter = null;
                  break;
                }
              }
            }).catch(error => {
              console.log(error)
              alert('Something went wrong!')
            })
        }
      }
    } else if (type == 'cabin'){
      if (confirm("Are you really want to delete cabin?")) {
        this.firebaseService.deleteCabin(this.layout.selectedCenter, this.layout.cabin)
          .then(res => {
            alert('Cabin has been deleted successfully!')
            for (let i = 0; i < this.layout.selectedCenter.cabins.length; i++) {
              if (this.layout.cabin.id == this.layout.selectedCenter.cabins[i].id) {
                this.layout.selectedCenter.cabins.splice(i, 1);
                this.addObject('cabin')
                break;
              }
            }
            document.getElementById(id).click();
          }).catch(error => {
            console.log(error)
            alert('Something went wrong!')
          })
      }
    } else if (type == 'desk') {
      if (confirm("Are you really want to delete desk?")) {
        this.firebaseService.deleteDesk(this.layout.selectedCenter, this.layout.desk)
          .then(res => {
            alert('Desk has been deleted successfully!')
            for (let i = 0; i < this.layout.selectedCenter.desks.length; i++) {
              if (this.layout.desk.id == this.layout.selectedCenter.desks[i].id) {
                this.layout.selectedCenter.desks.splice(i, 1);
                this.addObject('desk')
                break;
              }
            }
            document.getElementById(id).click();
          }).catch(error => {
            console.log(error)
            alert('Something went wrong!')
          })
      }
    } else if (type == 'conferenceRoom') {
      if (confirm("Are you really want to delete conference room?")) {
        this.firebaseService.deleteConferenceRoom(this.layout.selectedCenter, this.layout.conferenceRoom)
          .then(res => {
            alert('Conference room has been deleted successfully!')
            for (let i = 0; i < this.layout.selectedCenter.conferenceRooms.length; i++) {
              if (this.layout.conferenceRoom.id == this.layout.selectedCenter.conferenceRooms[i].id) {
                this.layout.selectedCenter.conferenceRooms.splice(i, 1);
                this.addObject('conferenceRoom')
                break;
              }
            }
            document.getElementById(id).click();
          }).catch(error => {
            console.log(error)
            alert('Something went wrong!')
          })
      }
    } else if (type == 'trainingRoom') {
      if (confirm("Are you really want to delete training room?")) {
        this.firebaseService.deleteTrainingRoom(this.layout.selectedCenter, this.layout.trainingRoom)
          .then(res => {
            alert('Training room has been deleted successfully!')
            for (let i = 0; i < this.layout.selectedCenter.trainingRooms.length; i++) {
              if (this.layout.trainingRoom.id == this.layout.selectedCenter.trainingRooms[i].id) {
                this.layout.selectedCenter.trainingRooms.splice(i, 1);
                this.addObject('trainingRoom')
                break;
              }
            }
            document.getElementById(id).click();
          }).catch(error => {
            console.log(error)
            alert('Something went wrong!')
          })
      }
    }
  }


  selectedCenter(center) {
    this.layout.selectedCenter = center;
    this.layout.newCenter = this.layout.selectedCenter;
    this.layout.newCenter.address['area_tags'] = []
    for (const key in this.layout.newCenter.address.area) {
      this.layout.newCenter.address.area_tags.push({ display: this.layout.newCenter.address.area[key], value: this.layout.newCenter.address.area[key]})
    }
  }

  selectedCenterCollectionObj(obj,type) {
    this.layout.selectedCenter['selectedCollectionObj'] = {obj:obj,type:type}
    if (type == 'cabin') {
      this.layout.cabin = obj
    } else if (type == 'desk') {
      this.layout.desk = obj
    } else if (type == 'conferenceRoom') {
      this.layout.conferenceRoom = obj
    } else if (type == 'trainingRoom') {
      this.layout.trainingRoom = obj
    }
  }

  updateObject(type, id) {
    if(type == 'center') {
      this.firebaseService.updateCenter(this.layout.newCenter)
      .then(res => {
        for(const center of this.layout.centers) {
          if (center.centerId == this.layout.newCenter.centerId) {
            center.address['tags'] = null;
            for (let i = 0; i < this.layout.newCenter.address.area_tags.length; i++) {
              if (center.address['tags'])
                center.address['tags'] += '/' +this.layout.newCenter.address.area_tags[i].value  
              else 
                center.address['tags'] = this.layout.newCenter.address.area_tags[i].value  
            }
          }
        }
        alert('Center has been updated successfully!')
        document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'cabin') {
      this.firebaseService.updateCabin(this.layout.newCenter, this.layout.cabin)
      .then(res => {
          alert('Cabin has been updated successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'desk') {
      this.firebaseService.updateDesk(this.layout.newCenter, this.layout.desk)
        .then(res => {
          alert('Desk has been updated successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    } else if (type == 'conferenceRoom') {
      this.firebaseService.updateConferenceRoom(this.layout.newCenter, this.layout.conferenceRoom)
        .then(res => {
          alert('Conference Room has been updated successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    } else if (type == 'trainingRoom') {
      this.firebaseService.updateTrainingRoom(this.layout.newCenter, this.layout.trainingRoom)
        .then(res => {
          alert('Training Room has been updated successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    }
  }


  editCenter() {
    if(!this.layout.selectedCenter)
      alert('Sorry! No center is selected')
    else {
      this.layout.newCenter = this.layout.selectedCenter;
    } 
  }

  getCenters() {
    this.firebaseService.getCenters()
    .then((res:any) => {
      this.layout.centers = []
      for(const center of res) {
        center.address['tags'] = center.address.area.tag1 + '/' + center.address.area.tag2 + '/' + center.address.area.tag3
        this.layout.centers.push(center);
      }
      console.log(res)
    }).catch(error => {
        console.log(error)
        alert('Something went wrong!')
    })
  }


  saveObject(type, id) {
    if(type == 'center') {
      this.layout.newCenter.address.area = {}
      for (let i = 0; i < this.layout.newCenter.address.area_tags.length; i++)
        this.layout.newCenter.address.area['tag' + (i + 1)] = this.layout.newCenter.address.area_tags[i].value
      delete this.layout.newCenter.address.area_tags  
      this.firebaseService.addCenter(this.layout.newCenter)
      .then(res => {
          alert('Center has been added successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'cabin') {
      this.firebaseService.addCabin(this.layout.selectedCenter, this.layout.cabin)
      .then(res => {
          alert('Cabin has been added successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'desk') {
      this.firebaseService.addDesk(this.layout.selectedCenter, this.layout.desk)
      .then(res => {
          alert('Desk has been added successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'conferenceRoom') {
      this.firebaseService.addConferenceRoom(this.layout.selectedCenter, this.layout.conferenceRoom)
        .then(res => {
          alert('Conference Room has been added successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    } else if (type == 'trainingRoom') {
      this.layout.trainingRoom.trainingId = 'T' + this.getRandomInt(1000000, 9999999);
      this.firebaseService.addTrainingRoom(this.layout.selectedCenter, this.layout.trainingRoom)
        .then(res => {
          alert('Training Room has been added successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    }
  }

  saveObjectsByExcel(type,id) {
    this.getUploadedFileInJsonFormat()
    .then(async (res: any) => {
        if (res) {
          if(type == 'center') {
            for (const ele of res) {
              let center = { contact: {}, address: {area:{}} };
              for (const key in ele) {
                if (ele.hasOwnProperty(key)) {
                  if (key.startsWith('contact'))
                    center.contact[key] = ele[key];
                  else if (key.startsWith('address_area_')) 
                    center.address.area[key.replace('address_area_', '')] = ele[key];
                  else if (key.startsWith('address_'))
                    center.address[key.replace('address_', '')] = ele[key];
                  else
                    center[key] = ele[key]
                }
              }
              await this.firebaseService.addCenter(center)
            }
            alert('Centers has been added successfully!')
          } else if (type == 'cabin') {
            for (const obj of res) {
              let cabin = JSON.parse(JSON.stringify(obj));
              cabin['price'] = {}
              for (const key in cabin) {
                if (cabin.hasOwnProperty(key)) {
                  if (key.startsWith('price_')) {
                    cabin.price[key.replace('price_', '')] = cabin[key];
                    delete cabin[key];
                  }
                }
              }
              await this.firebaseService.addCabin(this.layout.selectedCenter, cabin)
            }
            alert('Cabins has been added successfully!')
          } else if (type == 'desk') {
            for (const obj of res) {
              let desk = JSON.parse(JSON.stringify(obj));
              desk['price'] = {}
              for (const key in desk) {
                if (desk.hasOwnProperty(key)) {
                  if (key.startsWith('price_')) {
                    desk.price[key.replace('price_', '')] = desk[key];
                    delete desk[key];
                  }
                }
              }
              await this.firebaseService.addDesk(this.layout.selectedCenter, desk)
            }
            alert('Desks has been added successfully!')
          } else if (type == 'conferenceRoom') {
            for (const room of res) {
              let obj = JSON.parse(JSON.stringify(room));
              obj['price'] = {}
              for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                  if (key.startsWith('price_')) {
                    obj.price[key.replace('price_', '')] = obj[key];
                    delete obj[key];
                  }
                }
              }
              await this.firebaseService.addConferenceRoom(this.layout.selectedCenter, obj)
            }
            alert('Conference Rooms have been added successfully!')
          } else if (type == 'trainingRoom') {
            for (const room of res) {
              let obj = JSON.parse(JSON.stringify(room));
              obj['price'] = {}
              for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                  if (key.startsWith('price_')) {
                    obj.price[key.replace('price_', '')] = obj[key];
                    delete obj[key];
                  }
                }
              }
              await this.firebaseService.addTrainingRoom(this.layout.selectedCenter, obj)
            }
            alert('Training Rooms have been added successfully!')
          }
          document.getElementById(id).click();
        } else
          alert('Something went wrong!')
    }).catch(error => {
        console.log(error)
        alert('Something went wrong!')
    })
  }

  onFileChange(event) {
    this.file = event.target.files[0];
  }

  getUploadedFileInJsonFormat() {
    return new Promise((resolve, reject) => {
      try {
        let fileReader = new FileReader();
        fileReader.onload = (e) => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();
          for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
          var bstr = arr.join("");
          var workbook = XLSX.read(bstr, { type: "binary" });
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          resolve(XLSX.utils.sheet_to_json(worksheet, { raw: true }));
        }
        fileReader.readAsArrayBuffer(this.file);  
      } catch (error) {
        reject(error);
      }
    });
  }

  getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

}
