import { Component, EventEmitter, OnInit, Input, OnChanges } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { UserServiceService } from '../../services/user-service/user-service.service'

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnChanges, OnInit {

  submitted = false;
  profileForm: FormGroup;
  address: FormGroup
  roles = ['admin', 'user', 'manager', 'security'];
  centersArr: any = []
  tempCenter: any = {}

  //isCenter: any = false;

  isCenterThere: boolean = false;


  @Input()
  modelUser: any;


  @Input()
  isEdit: boolean = false;

  isSubmited: boolean = false
  constructor(private fb: FormBuilder, private userService: UserServiceService) { }

  ngOnChanges() {
    this.getFormGroup()
    // this.checkCenter()
    this.isSubmited = false;
  }

  ngOnInit() {
    this.getFormGroup()
  }

  getResetForm() {
    this.profileForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      role: ['', Validators.required],
      cen: [''],
      address: this.fb.group({
        street: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        zip: ['', Validators.required]
      })
    })
  }

  getFormGroup() {
    this.profileForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      role: ['', Validators.required],
      address: this.fb.group({
        street: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        zip: ['', Validators.required]
      }),
    })
    console.log(this.modelUser);


    if (this.modelUser && this.modelUser.displayName && this.modelUser.email && this.modelUser.address && this.modelUser.role) {
      let tempArr = this.modelUser.displayName.split(" ")
      let role = ""
      if (this.modelUser.role.admin) {
        role = "admin"
        if (this.modelUser.center_ref) {
          this.isCenterThere = true
          this.userService.getAdminCenter(this.modelUser.center_ref).subscribe(res => {
            console.log("res >>> ", res);
            this.centersArr = []
            this.centersArr.push(res)
          }, err => {
            console.log("No center list found.", err);

          })
        }
      } else if (this.modelUser.role.user) {
        role = "user"
      } else if (this.modelUser.role.manager) {
        role = "manager"
      } else if (this.modelUser.role.security) {
        role = "security"
      }

      let street = "", city = "", state = "", zip = ""
      if (this.modelUser.address.street)
        street = this.modelUser.address.street

      if (this.modelUser.address.city)
        city = this.modelUser.address.city

      if (this.modelUser.address.state)
        state = this.modelUser.address.state

      if (this.modelUser.address.zip)
        zip = this.modelUser.address.zip

      let address = {
        street: street,
        city: city,
        state: state,
        zip: zip
      }

      if(this.modelUser.center_ref){
        if (this.modelUser.role.admin) {
          this.userService.getCenterUsingCenterId(this.modelUser.center_ref).subscribe(res => {
            if (res) {
              this.isCenterThere = true
              this.centersArr = res
              console.log(this.centersArr);
            } else {
              this.isCenterThere = false
              this.centersArr[0] = "No centers found." + this.profileForm.value.address.city
              console.log("No centers found in ", this.profileForm.value.address.city)
            }
          }, err => {
            this.isCenterThere = false
            console.log("No centers found..", err)
          })
    
        } else {
          this.isCenterThere = false;
          this.centersArr = []
        }
      }

      this.profileForm.setValue({
        firstName: tempArr[0],
        lastName: tempArr[1],
        email: this.modelUser.email,
        address: address,//this.modelUser.address,
        role: role
      });
    }
  }

  onSubmit() {
    this.submitted = true
    let role = this.profileForm.value.role;
    if (role === "manager") {
      role = { "manager": true }
    } else if (role === "user") {
      role = { "user": true }
    } else if (role === "security") {
      role = { "security": true }
    } else if (role === "admin") {
      role = { "admin": true }
    }
    this.profileForm.value.role = role
    if (!this.isEdit) {
      this.userService.addUser(this.profileForm.value, this.tempCenter.center_id).subscribe(res => {
        console.log("res >> ", res)
        this.centersArr = []
        this.isCenterThere = false;
        this.getResetForm()
      }, err => {
        console.log("err >> ", err)
      })
    }
    else {
      let editModel = this.profileForm.value
      editModel.uid = this.modelUser.uid
      console.log("editModel >> ", editModel);
      this.userService.editUser(editModel, this.tempCenter.centerId).subscribe(res => {
        console.log("res >> ", res)
        this.centersArr = []
        this.isCenterThere = false;
        this.getResetForm()
      }, err => {
        console.log("err >> ", err)
      })
    }

  }

  onSelectCenter(event, center) {
    event.preventDefault()
    console.log("center >> ", center);

    this.tempCenter = center
  }
  
  checkCenter(event) {
    event.preventDefault()
    console.log(">> ", this.profileForm.value.role)
    if (this.profileForm.value.role === "admin") {

      this.userService.getCenters(this.profileForm.value.address.city).subscribe(res => {
        if (res) {
          this.isCenterThere = true
          this.centersArr = res
          console.log(this.centersArr);
        } else {
          this.isCenterThere = false
          this.centersArr[0] = "No centers found." + this.profileForm.value.address.city
          console.log("No centers found in ", this.profileForm.value.address.city)
        }
      }, err => {
        this.isCenterThere = false
        console.log("No centers found..", err)
      })

    } else {
      this.isCenterThere = false;
      this.centersArr = []
    }
  }

}
