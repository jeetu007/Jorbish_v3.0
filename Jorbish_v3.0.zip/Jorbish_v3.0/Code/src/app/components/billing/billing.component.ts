import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { BillingService } from "../../services/billing/billing.service";

@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.css']
})
export class BillingComponent implements OnInit {

  viewSelectedBooking: any;
  currDate = new Date();
  payUrl : any;

  constructor(public route:ActivatedRoute,public billingService: BillingService ,private router:Router) {

  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      console.log(params['orderId']);
      this.billingService.getBilling(params['orderId']).subscribe(response => {
      
      response.forEach(billResponse => {
      
      this.viewSelectedBooking = billResponse.data();
      console.log(this.viewSelectedBooking);
      
      let payload = {
      "ORDER_ID": this.viewSelectedBooking.billingId,
      "CUST_ID": this.viewSelectedBooking.clientId,
      "MOBILE_NO": 7777777777,
      "EMAIL": "xyz@gmail.com",
      "TXN_AMOUNT": this.viewSelectedBooking.totalAmount,
      "CALLBACK_URL": "http://localhost:4200/payment-status/"
      }
      
      // this.payUrl = "https://us-central1-urssystemsapp.cloudfunctions.net/payment/testtxn"?
      
      // this.payUrl = "http://localhost:5000/jorbish-79a9b/us-central1/payment/testtxn?";
      
      this.payUrl = "https://us-central1-jorbish-79a9b.cloudfunctions.net/payment/testtxn?";
      
      for (const key in payload)
      this.payUrl += key + '=' + payload[key] + '&';
      
      console.log(this.payUrl);
      });
      });
      
      });
  }//ngOnInit()

}
