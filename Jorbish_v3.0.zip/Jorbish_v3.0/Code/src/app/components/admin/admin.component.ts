import { Component, OnInit } from '@angular/core';

import { Router } from "@angular/router";

import { AuthService } from "../../services/auth/auth.service";
import { FirebaseService } from '../../services/superadmin/firebase.service';
import * as XLSX from 'ts-xlsx';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  public arrayBuffer: any;
  public file: File;
  public layout:any = {
    centers:null,
    selectedCenter:null,
    newCenter:{
      centerId:null,
      contact:{contactPerson:null,contactNumber:null,contactEmail:null},
      address: { addressLine1: null, addressLine2: null, area: null, city: null, state: null, country:null,pincode:null}
    },
    cabin:{
      cabinId:null,
      name:null,
      capacity:null,
      dimension:null,
      info:null,
      status:null,
      price:null
    },
    desk: {
      deskId: null,
      Type : null,
      dimension: null,
      info: null,
      status: null,
      price: null
    },
    conferenceRoom : {
      conferenceId: null,
      capacity: null,
      dimension: null,
      info: null,
      status: null,
      price: null
    },
    trainingRoom : {
      trainingId: null,
      capacity: null,
      dimension: null,
      info: null,
      status: null,
      price: null
    }

  }

  constructor(private firebaseService:FirebaseService,public router: Router,public authService: AuthService) { 

  }

  ngOnInit() {
    this.getCenters();  
  }

  addObject(type) {
    if(type == 'center') {
      this.layout.newCenter = {
        centerId: null,
        contact: { contactPerson: null, contactNumber: null, contactEmail: null },
        address: { addressLine1: null, addressLine2: null, area: null, city: null, state: null, country: null, pincode: null }
      }
    } else if (type == 'cabin') {
      this.layout.cabin = {
        cabinId: null,
        name: null,
        capacity: null,
        dimension: null,
        info: null,
        status: null,
        price: null
      }
    } else if (type == 'desk') {
      this.layout.cabin = {
        deskId: null,
        Type: null,
        dimension: null,
        info: null,
        status: null,
        price: null
      }
    } else if (type == 'conferenceRoom') {
      this.layout.conferenceRoom = {
        conferenceId: null,
        capacity: null,
        dimension: null,
        info: null,
        status: null,
        price: null
      }
    } else if (type == 'trainingRoom') {
      this.layout.trainingRoom = {
        trainingId: null,
        capacity: null,
        dimension: null,
        info: null,
        status: null,
        price: null
      }
    }
  }


  getCenterCollectionByType(type) {
    if (!this.layout.selectedCenter)
      alert('Sorry! No center is selected')
    else {
      this.firebaseService.getCenterCollectionByType(this.layout.selectedCenter, type)
      .then(res => {
        this.layout.selectedCenter[type] = res;
      }).catch(error => {
        console.log(error)
        alert('Something went wrong!')
      })
    }
  }

  selectedCenter(center) {
    this.layout.selectedCenter = center;
    this.layout.newCenter = this.layout.selectedCenter;
  }

  selectedCenterCollectionObj(obj,type) {
    this.layout.selectedCenter['selectedCollectionObj'] = {obj:obj,type:type}
    if (type == 'cabin') {
      this.layout.cabin = obj
    } else if (type == 'desk') {
      this.layout.desk = obj
    } else if (type == 'conferenceRoom') {
      this.layout.conferenceRoom = obj
    } else if (type == 'trainingRoom') {
      this.layout.trainingRoom = obj
    }
  }

  updateObject(type, id) {
    if(type == 'center') {
      this.firebaseService.updateCenter(this.layout.newCenter)
      .then(res => {
          console.log(res);
          alert('Center has been updated successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'cabin') {
      this.firebaseService.updateCabin(this.layout.newCenter, this.layout.cabin)
      .then(res => {
          alert('Cabin has been updated successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'desk') {
      this.firebaseService.updateDesk(this.layout.newCenter, this.layout.desk)
        .then(res => {
          alert('Desk has been updated successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    } else if (type == 'conferenceRoom') {
      this.firebaseService.updateConferenceRoom(this.layout.newCenter, this.layout.conferenceRoom)
        .then(res => {
          alert('Conference Room has been updated successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    } else if (type == 'trainingRoom') {
      this.firebaseService.updateTrainingRoom(this.layout.newCenter, this.layout.trainingRoom)
        .then(res => {
          alert('Training Room has been updated successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    }
  }


  editCenter() {
    if(!this.layout.selectedCenter)
      alert('Sorry! No center is selected')
    else {
      this.layout.newCenter = this.layout.selectedCenter;
    } 
  }

  getCenters() {
    this.firebaseService.getCenters()
    .then(res => {
      this.layout.centers = res;
      console.log(res)
    }).catch(error => {
        console.log(error)
        alert('Something went wrong!')
    })
  }


  saveObject(type, id) {
    if(type == 'center') {
      this.layout.newCenter.centerId = 'C' + this.getRandomInt(1000000, 9999999);
      this.firebaseService.addCenter(this.layout.newCenter)
      .then(res => {
          alert('Center has been added successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'cabin') {
      this.layout.cabin.cabinId = 'C' + this.getRandomInt(1000000, 9999999);
      this.firebaseService.addCabin(this.layout.selectedCenter, this.layout.cabin)
      .then(res => {
          alert('Cabin has been added successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'desk') {
      this.layout.cabin.deskId = 'D' + this.getRandomInt(1000000, 9999999);
      this.firebaseService.addDesk(this.layout.selectedCenter, this.layout.cabin)
      .then(res => {
          alert('Desk has been added successfully!')
          document.getElementById(id).click();
      }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
      })
    } else if (type == 'conferenceRoom') {
      this.layout.conferenceRoom.conferenceId = 'C' + this.getRandomInt(1000000, 9999999);
      this.firebaseService.addConferenceRoom(this.layout.selectedCenter, this.layout.conferenceRoom)
        .then(res => {
          alert('Conference Room has been added successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    } else if (type == 'trainingRoom') {
      this.layout.trainingRoom.trainingId = 'T' + this.getRandomInt(1000000, 9999999);
      this.firebaseService.addTrainingRoom(this.layout.selectedCenter, this.layout.trainingRoom)
        .then(res => {
          alert('Training Room has been added successfully!')
          document.getElementById(id).click();
        }).catch(error => {
          console.log(error)
          alert('Something went wrong!')
        })
    }
  }

  saveObjectsByExcel(type,id) {
    this.getUploadedFileInJsonFormat()
    .then(async (res: any) => {
        if (res) {
          if(type == 'center') {
            for (const ele of res) {
              let center = { contact: {}, address: {} };
              for (const key in ele) {
                if (ele.hasOwnProperty(key)) {
                  if (key.startsWith('contact'))
                    center.contact[key] = ele[key];
                  else if (key.startsWith('address_'))
                    center.address[key.replace('address_', '')] = ele[key];
                  else
                    center[key] = ele[key]
                }
              }
              await this.firebaseService.addCenter(center)
            }
            alert('Centers has been added successfully!')
          } else if (type == 'cabin') {
            for (const cabin of res) {
              await this.firebaseService.addCabin(this.layout.selectedCenter, cabin)
            }
            alert('Cabins has been added successfully!')
          } else if (type == 'desk') {
            for (const desk of res) {
              await this.firebaseService.addDesk(this.layout.selectedCenter, desk)
            }
            alert('Desks has been added successfully!')
          } else if (type == 'conferenceRoom') {
            for (const room of res) {
              await this.firebaseService.addConferenceRoom(this.layout.selectedCenter, room)
            }
            alert('Conference Rooms have been added successfully!')
          } else if (type == 'trainingRoom') {
            for (const room of res) {
              await this.firebaseService.addTrainingRoom(this.layout.selectedCenter, room)
            }
            alert('Training Rooms have been added successfully!')
          }
          document.getElementById(id).click();
        } else
          alert('Something went wrong!')
    }).catch(error => {
        console.log(error)
        alert('Something went wrong!')
    })
  }

  onFileChange(event) {
    this.file = event.target.files[0];
  }

  getUploadedFileInJsonFormat() {
    return new Promise((resolve, reject) => {
      try {
        let fileReader = new FileReader();
        fileReader.onload = (e) => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();
          for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
          var bstr = arr.join("");
          var workbook = XLSX.read(bstr, { type: "binary" });
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          resolve(XLSX.utils.sheet_to_json(worksheet, { raw: true }));
        }
        fileReader.readAsArrayBuffer(this.file);  
      } catch (error) {
        reject(error);
      }
    });
  }

  getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  logout($event){
    this.authService.signOut().then(res => {
      this.router.navigate(['login']);
    }).catch(err => {
      this.router.navigate(['login']);
    });
  }//logout(-)

}
