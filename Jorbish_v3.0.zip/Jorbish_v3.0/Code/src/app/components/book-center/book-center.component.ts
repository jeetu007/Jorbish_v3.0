import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FirebaseService } from '../../services/superadmin/firebase.service';
import { AuthService } from '../../services/auth/auth.service';
import { ClientService } from '../../services/client/client.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-book-center',
  templateUrl: './book-center.component.html',
  styleUrls: ['./book-center.component.css']
})
export class BookCenterComponent implements OnInit {

  startDate = "";
  duration: any;
  bookingSpaces: any = [];

  spaceBoolean = false;

  centerList: any = [];
  selectedCenterBoolean: boolean = false;
  selectedCenterId: any;
  public bookingDetails: any = [];
  public currentUser: any;


  constructor(public router: Router, private firebaseService: FirebaseService,
    private authService: AuthService, private clientService: ClientService, private toastr: ToastrService) { }

  ngOnInit() {
    let user = this.authService.user$.subscribe(user => {
      this.currentUser = user;
    }, err => {
      console.log("Auth User Err ->", err);
    })
  }

  selectedCenter(center, event) {
    if (event.target.checked) {
      this.firebaseService.getCenterId(center.centerId).subscribe(res => {
        this.selectedCenterId = res.docs[0].id;
        localStorage.setItem("currentCenterId", this.selectedCenterId);
        this.selectedCenterBoolean = true;
      })
    } else {
      this.selectedCenterBoolean = false;
    }
  }

  searchCenter(event) {
    if (event.target.value && event.target.value.length >= 3) {
      this.firebaseService.searchCenter(event.target.value.toUpperCase()).subscribe(res => {
        this.centerList= [];
        res.docs.forEach(doc => {
          doc.data()["docId"] = doc.id;
          this.centerList.push(doc.data());
        })
      })
    } else if(event.target.value.length == 0){
      this.centerList= [];
    }
  }

  filterExistingSpaces() {
    this.bookingSpaces.filter((elem) => {
      for (let i = 0; i < this.bookingDetails.length; i++) {
        if (elem.id == this.bookingDetails[i].id) {
          elem['selected'] = true;
        }
      }
    });
  }

  selectedSpace(event) {
    this.spaceBoolean = true;
    if (event.target.value === "desk") {
      this.bookingSpaces = [];
      this.firebaseService.getCenterSpace('desks', this.selectedCenterId).subscribe(res => {
        res.docs.forEach(doc => {
          let deskData = {
            "id": doc.id,
            "dimension": doc.data().dimension,
            "status": doc.data().status,
            "priceId": doc.data().price,
            "spaceType": 'desk'
          };
          this.bookingSpaces.push(deskData);
        });
        this.filterExistingSpaces();
      });

    } else if (event.target.value === "cabin") {
      this.bookingSpaces = [];
      this.firebaseService.getCenterSpace('cabins', this.selectedCenterId).subscribe(res => {
        res.docs.forEach(doc => {
          let deskData = {
            "id": doc.id,
            "dimension": doc.data().dimension,
            "status": doc.data().status,
            "priceId": doc.data().price,
            "spaceType": 'cabin'
          };
          this.bookingSpaces.push(deskData);
        });
        this.filterExistingSpaces();
      })

    } else if (event.target.value === "conferenceroom") {
      this.bookingSpaces = [];
      this.firebaseService.getCenterSpace('conferenceRooms', this.selectedCenterId).subscribe(res => {
        res.docs.forEach(doc => {
          let deskData = {
            "id": doc.id,
            "dimension": doc.data().dimension,
            "priceId": doc.data().price,
            "status": doc.data().status,
            "spaceType": 'conferenceroom'
          };
          this.bookingSpaces.push(deskData);
        });
        this.filterExistingSpaces();
      })

    } else if (event.target.value === "trainingroom") {
      this.bookingSpaces = [];
      this.firebaseService.getCenterSpace('trainingRooms', this.selectedCenterId).subscribe(res => {
        res.docs.forEach(doc => {
          let deskData = {
            "id": doc.id,
            "dimension": doc.data().dimension,
            "status": doc.data().status,
            "priceId": doc.data().price,
            "spaceType": 'trainingroom'
          };
          this.bookingSpaces.push(deskData);
        });
        this.filterExistingSpaces();
      })
    }
  }

  selectedBookingSpace(event, space) {
    if (event.target.checked) {
      let bookingInfo = {
        id: space.id,
        spaceType: space.spaceType,
        priceId: space.priceId,
        timeUnit: this.duration,
        startTime: this.startDate,
        endTime: "",
        totalTime: ""
      };
      let existingSpace = false;
      if (this.bookingDetails.length > 0) {
        for (let i = 0; i < this.bookingDetails.length; i++) {
          if (space.id === this.bookingDetails[i].id) {
            existingSpace = true;
          }
        }
      }
      if (!existingSpace) {
        this.bookingDetails.push(bookingInfo);
      }
    } else {
      let index = this.bookingDetails.indexOf(space);
      this.bookingDetails.splice(index, 1);
    }
  }

  viewBooking() {
    this.clientService.setBookingDetail(this.bookingDetails);
  }

  proceedToClient() {
    this.router.navigate(['add-client/' + this.selectedCenterId]);
  }

  //Future use case for user/client booking with availability notification
  saveClientInfo() {
    this.authService.user$.subscribe(user => {
      let userInitiatedBookingInfo = {
        user: user,
        bookingDetails: this.bookingDetails,
        centerId: this.selectedCenterId
      }
      console.log("userInitiatedBookingInfo --> ", userInitiatedBookingInfo);
      this.toastr.success("Thank you for your interest. We will get back to you soon.");
    }, err => {
      console.log("user err --> ", err);
      this.toastr.error("Something went wrong. Please try again");
    });
  }

  logout($event) {
    this.authService.signOut().then(res => {
      this.router.navigate(['login']);
    }).catch(err => {
      this.router.navigate(['login']);
    });
  }//logout(-)

}
