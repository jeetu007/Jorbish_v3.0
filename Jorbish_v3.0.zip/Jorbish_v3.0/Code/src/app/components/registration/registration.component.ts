import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  userRef: any;
  googleUser: any;
  userRole: any = {};
  userData: any = {};
  userAdditionalInfo = {};
  address : any = {}

  constructor(private route: ActivatedRoute, private authService: AuthService) {
  }

  ngOnInit() {
    this.userRef = this.authService.getUserRef();
    this.googleUser = this.authService.getUser();
    console.log(this.userRef, this.googleUser);
  }

  checkRole(event) {
    console.log(event);
    this.userRole[event.target.value] = event.target.checked;
    console.log(this.userRole);
  }

  onSubmit(event) {
    event.preventDefault();
    this.userData.displayName = this.googleUser.displayName;
    this.userData.email = this.googleUser.email;
    this.userData.photoURL = this.googleUser.photoURL;
    this.userData.uid = this.googleUser.uid;
    this.userData.address = this.address//this.userAdditionalInfo['address'];
    this.userData['role'] = this.userRole;
    console.log("Submit => ", this.userData);
    this.userRef.set(this.userData, { merge: true });
    this.userRole = {};
    this.userAdditionalInfo = {};
  }

}
