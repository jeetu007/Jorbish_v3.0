import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";

import { AuthService } from "../../services/auth/auth.service";
import { BillingService } from "../../services/billing/billing.service";

@Component({
  selector: 'app-payment-status',
  templateUrl: './payment-status.component.html',
  styleUrls: ['./payment-status.component.css']
})
export class PaymentStatusComponent implements OnInit {

  orderId: any;
  transactionResponse:any;
  billingResponse:any;
  billingDetails:any;

  constructor(private route: ActivatedRoute, public billingService: BillingService, public router: Router, public authService: AuthService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.orderId = params['orderId'];
      this.updateTransaction(this.orderId);
    });
  }

  updateTransaction(orderId) {
console.log("orderId == ", orderId);

    this.billingService.getPaytmTransaction(orderId).subscribe(res => {

      res.forEach(txnResponse => {
        this.transactionResponse = txnResponse.data()
console.log("==",txnResponse.data());

        let transactionTable = {
          orderId: this.transactionResponse.ORDERID,
          transactionId : this.transactionResponse.TXNID,
          transactionDate : this.transactionResponse.TXNDATE,
          paymentGatewayId : this.transactionResponse.GATEWAYNAME,
          webhookId : this.transactionResponse.MID,
          transactionAmount : this.transactionResponse.TXNAMOUNT,
          transactionStatus : this.transactionResponse.STATUS
        }

        this.billingService.getBilling(orderId).subscribe(billRes => {

          billRes.forEach(billResponse => {
            
              this.billingResponse = billResponse.data();
                     console.log( 'billingRes===>',this.billingResponse);
                     
              transactionTable["clientId"] = this.billingResponse.clientId;

              this.billingService.saveTransaction(transactionTable);

              let billingHistroy= {
                bookingDetail :  this.billingResponse.bookingDetail,
                currency :  'INR' ,
                invoiceNumber : orderId,
                payment_type : this.transactionResponse.GATEWAYNAME,
                payment_status : this.transactionResponse.STATUS,
                center_id : this.billingResponse.centerId,
                client_id : this.billingResponse.clientId,
                billing_id : this.billingResponse.billingId,    
                txn_id     :   this.transactionResponse.TXNID
                }
                
            this.billingService.billingHistroy(billingHistroy);
            
          });

        });
         
      });

    });


  }//updateTransaction(-)


  logout($event) {
    this.authService.signOut().then(res => {
      this.router.navigate(['login']);
    }).catch(err => {
      this.router.navigate(['login']);
    });
  }//logout(-)

}
