import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {


  constructor(
    private firestore: AngularFirestore) {

  }

  updateCenter(center) {
    let obj = JSON.parse(JSON.stringify(center))
    for (let i = 0; i < obj.address.area_tags.length; i++)
      obj.address.area['tag' + (i + 1)] = obj.address.area_tags[i].value
    delete obj.address.area_tags
    return this.firestore.collection('centers').doc(obj.id).update({
      centerId: obj.centerId,
      contact: obj.contact,
      address: obj.address,
    })
  }

  async updateCabin(center, cabin) {
    let obj = JSON.parse(JSON.stringify(cabin))
    await this.firestore.collection('price_masters').doc(obj.price.id).update({
      minutes: obj.price.minutes,
      hourly: obj.price.hourly,
      daily: obj.price.daily,
      monthly: obj.price.monthly
    })
    obj.price = obj.price.id
    return this.firestore.collection('centers').doc(center.id).collection('cabins').doc(obj.id).update(obj)
  }

  async updateDesk(center, desk) {
    let obj = JSON.parse(JSON.stringify(desk))
    await this.firestore.collection('price_masters').doc(obj.price.id).update({
      minutes: obj.price.minutes,
      hourly: obj.price.hourly,
      daily: obj.price.daily,
      monthly: obj.price.monthly
    })
    obj.price = obj.price.id
    return this.firestore.collection('centers').doc(center.id).collection('desks').doc(obj.id).update(obj)
  }

  async updateConferenceRoom(center, conferenceRoom) {
    let obj = JSON.parse(JSON.stringify(conferenceRoom))
    await this.firestore.collection('price_masters').doc(obj.price.id).update({
      minutes: obj.price.minutes,
      hourly: obj.price.hourly,
      daily: obj.price.daily,
      monthly: obj.price.monthly
    })
    obj.price = obj.price.id
    return this.firestore.collection('centers').doc(center.id).collection('conferenceRooms').doc(obj.id).update(obj)
  }

  async updateTrainingRoom(center, trainingRoom) {
    let obj = JSON.parse(JSON.stringify(trainingRoom))
    await this.firestore.collection('price_masters').doc(obj.price.id).update({
      minutes: obj.price.minutes,
      hourly: obj.price.hourly,
      daily: obj.price.daily,
      monthly: obj.price.monthly
    })
    obj.price = obj.price.id
    return this.firestore.collection('centers').doc(center.id).collection('trainingRooms').doc(obj.id).update(obj)
  }


  deleteCenter(center) {
    return this.firestore.collection('centers').doc(center.id).delete();
  }

  async deleteCabin(center, cabin) {
    await this.firestore.collection('price_masters').doc(cabin.price.id).delete()
    return this.firestore.collection('centers').doc(center.id).collection('cabins').doc(cabin.id).delete();
  }

  async deleteDesk(center, desk) {
    await this.firestore.collection('price_masters').doc(desk.price.id).delete()
    return this.firestore.collection('centers').doc(center.id).collection('desks').doc(desk.id).delete();
  }

  async deleteConferenceRoom(center, conferenceRoom) {
    await this.firestore.collection('price_masters').doc(conferenceRoom.price.id).delete()
    return this.firestore.collection('centers').doc(center.id).collection('conferenceRooms').doc(conferenceRoom.id).delete();
  }

  async deleteTrainingRoom(center, trainingRoom) {
    await this.firestore.collection('price_masters').doc(trainingRoom.price.id).delete()
    return this.firestore.collection('centers').doc(center.id).collection('desks').doc(trainingRoom.id).delete();
  }

  addCenter(center) {
    return new Promise(async (resolve, reject) => {
      let centerLastSequence = 0;
      let seqeunce = await this.firestore.collection('temp_seq').doc('center_seq').get().toPromise()
      if (seqeunce.exists) {
        centerLastSequence = seqeunce.get('centerLastSequence');
        centerLastSequence++;
      } else {
        await this.firestore.collection('temp_seq').doc('center_seq').set({ centerLastSequence: 0 })
        centerLastSequence = 1;
      }

      if (centerLastSequence < 9)
        center['centerId'] = center.address.city.substring(0, 2).toUpperCase() + '00' + centerLastSequence;
      else if (centerLastSequence < 99)
        center['centerId'] = center.address.city.substring(0, 2).toUpperCase() + '0' + centerLastSequence;
      else
        center['centerId'] = center.address.city.substring(0, 2).toUpperCase() + centerLastSequence;

      this.firestore.collection('centers').add(center)
        .then(data => {
          this.firestore.collection('temp_seq').doc('center_seq').update({ centerLastSequence: centerLastSequence });
          resolve(data);
        }).catch(error => {
          reject(error);
        })
    })
  }

  async addCabin(center, cabin) {
    let price = await this.firestore.collection('price_masters').add(cabin.price)
    cabin.price = price.id

    let cabinLastSequence = 1;
    let seqeunce = await this.firestore.collection('centers').doc(center.id).get().toPromise()
    if (seqeunce.get('cabinLastSequence')) {
      cabinLastSequence = seqeunce.get('cabinLastSequence');
      ++cabinLastSequence;
    }

    if (cabinLastSequence < 9)
      cabin.cabinId = center.centerId + 'C00' + cabinLastSequence;
    else if (cabinLastSequence < 99)
      cabin.cabinId = center.centerId + 'C0' + cabinLastSequence;
    else
      cabin.cabinId = center.centerId + 'C' + cabinLastSequence;

    let res = await this.firestore.collection('centers').doc(center.id).collection('cabins').add(cabin);
    await this.firestore.collection('centers').doc(center.id).update({ cabinLastSequence: cabinLastSequence })
    return res;
  }

  async addDesk(center, desk) {
    let price = await this.firestore.collection('price_masters').add(desk.price)
    desk.price = price.id

    let deskLastSequence = 1;
    let seqeunce = await this.firestore.collection('centers').doc(center.id).get().toPromise()
    if (seqeunce.get('deskLastSequence')) {
      deskLastSequence = seqeunce.get('deskLastSequence');
      ++deskLastSequence;
    }

    if (deskLastSequence < 9)
      desk.deskId = center.centerId + 'C' + desk.type.charAt(0).toUpperCase() + '00' + deskLastSequence;
    else if (deskLastSequence < 99)
      desk.deskId = center.centerId + 'C' + desk.type.charAt(0).toUpperCase() + '0' + deskLastSequence;
    else
      desk.deskId = center.centerId + 'C' + desk.type.charAt(0).toUpperCase() + deskLastSequence;

    let res = await this.firestore.collection('centers').doc(center.id).collection('desks').add(desk);
    await this.firestore.collection('centers').doc(center.id).update({ deskLastSequence: deskLastSequence })
    return res;
  }

  async addConferenceRoom(center, conferenceRoom) {
    let price = await this.firestore.collection('price_masters').add(conferenceRoom.price)
    conferenceRoom.price = price.id

    let conferenceRoomLastSequence = 1;
    let seqeunce = await this.firestore.collection('centers').doc(center.id).get().toPromise()
    if (seqeunce.get('conferenceRoomLastSequence')) {
      conferenceRoomLastSequence = seqeunce.get('conferenceRoomLastSequence');
      ++conferenceRoomLastSequence;
    }

    if (conferenceRoomLastSequence < 9)
      conferenceRoom.conferenceId = center.centerId + 'C00' + conferenceRoomLastSequence;
    else if (conferenceRoomLastSequence < 99)
      conferenceRoom.conferenceId = center.centerId + 'C0' + conferenceRoomLastSequence;
    else
      conferenceRoom.conferenceId = center.centerId + 'C' + conferenceRoomLastSequence;

    let res = await this.firestore.collection('centers').doc(center.id).collection('conferenceRooms').add(conferenceRoom);
    await this.firestore.collection('centers').doc(center.id).update({ conferenceRoomLastSequence: conferenceRoomLastSequence })
    return res;
  }

  async addTrainingRoom(center, trainingRoom) {
    let price = await this.firestore.collection('price_masters').add(trainingRoom.price)
    trainingRoom.price = price.id

    let trainingRoomLastSequence = 1;
    let seqeunce = await this.firestore.collection('centers').doc(center.id).get().toPromise()
    if (seqeunce.get('trainingRoomLastSequence')) {
      trainingRoomLastSequence = seqeunce.get('trainingRoomLastSequence');
      ++trainingRoomLastSequence;
    }

    if (trainingRoomLastSequence < 9)
      trainingRoom.trainingId = center.centerId + 'T00' + trainingRoomLastSequence;
    else if (trainingRoomLastSequence < 99)
      trainingRoom.trainingId = center.centerId + 'T0' + trainingRoomLastSequence;
    else
      trainingRoom.trainingId = center.centerId + 'C' + trainingRoomLastSequence;

    let res = await this.firestore.collection('centers').doc(center.id).collection('trainingRooms').add(trainingRoom);
    await this.firestore.collection('centers').doc(center.id).update({ trainingRoomLastSequence: trainingRoomLastSequence })
    return res;
  }


  getCenterCollectionByType(center, type) {
    return new Promise((resolve, reject) => {
      this.firestore.collection('centers').doc(center.id).collection(type).get().toPromise()
        .then(async (data: any) => {
          const collections = [];
          for (const ele of data.docs) {
            let obj = ele.data()
            if (type != 'clients') {
              let price = await this.firestore.collection('price_masters').doc(obj.price).get().toPromise()
              obj.price = price.data()
              obj.price['id'] = price.id
            } else {
                
            }
            obj['id'] = ele.id
            collections.push(obj)
          }
          resolve(collections);
        }).catch(error => {
          reject(error)
        })
    })
  }

  getCenters() {
    return new Promise((resolve, reject) => {
      this.firestore.collection('centers').get().toPromise()
        .then((data: any) => {
          const centers = [];
          for (const ele of data.docs) {
            let obj = ele.data()
            obj['id'] = ele.id
            centers.push(obj)
          }
          resolve(centers);
        }).catch(error => {
          reject(error)
        })
    })
  }

  getCenterId(centerId) {
    return this.firestore.collection('centers', ref => ref.where('centerId', '==', centerId)).get();
  }

  addClientToCenter(centerId, client) {
    return this.firestore.collection('centers').doc(centerId)
      .collection('clients').doc(client.clientId).set(client, { merge: true });
  }

  getCenterSpace(spaceName, centerId) {
    return this.firestore.collection('centers').doc(centerId).collection(spaceName).get();
  }

  searchCenter(area) {
    return this.firestore.collection('centers', ref => ref.where('address.area.tag1', '==', area)
      .where('address.area.tag2', '==', area).where('address.area.tag3', '==', area)).get();
  }


}
