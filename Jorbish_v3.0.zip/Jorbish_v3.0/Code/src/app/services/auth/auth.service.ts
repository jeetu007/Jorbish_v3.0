import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { map } from 'rxjs/operators';

import { Router } from '@angular/router';
import * as firebase from 'firebase/app';

import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  user$: Observable<any>;
  userRef: any;
  user: any;

  constructor(private afAuth: AngularFireAuth,
    private afs: AngularFirestore,
    private router: Router) {

    //// Get auth data, then get firestore user document || null
    this.user$ = this.afAuth.authState
      .pipe(switchMap(user => {
        if (user) {
          return this.afs.doc<any>(`users/${user.uid}`).valueChanges()
        } else {
          return of(null)
        }
      }
      ));

  }

  ///// Login/Signup //////
  googleLogin() {
    const provider = new firebase.auth.GoogleAuthProvider()
    return this.oAuthLogin(provider);
  }

  private oAuthLogin(provider) {
    return this.afAuth.auth.signInWithPopup(provider)
      .then((credential) => {
        this.updateUserData(credential.user)
      })
  }

  private updateUserData(user) {
    // Sets user data to firestore on login
    console.log("credential--user-->", user);
    this.setUser(user);
    const userRef: AngularFirestoreDocument<any> = this.afs.doc(`users/${user.uid}`);
    userRef.get().subscribe(user => {
      if (user.data() && user.data().role) {
        console.log("user data role =>", user.data().role);
        if (user.data().role['admin']) {
          this.router.navigate(['admin']);
        } else if (user.data().role['user']) {
          this.router.navigate(['book-center']);
        } else if (user.data().role['superadmin']) {
          this.router.navigate(['superadmin']);
        }

      } else {
        this.setUserRef(userRef);
        this.router.navigate(['registration']);
      }
    })
  }

  signOut() {
    return this.afAuth.auth.signOut();
  }

  setUserRef(userRef) {
    this.userRef = userRef;
  }

  getUserRef() {
    return this.userRef;
  }

  setUser(userInfo) {
    this.user = userInfo;
  }

  getUser() {
    return this.user;
  }
  ///// Role-based Authorization //////
  canAdminView(user: any): boolean {
    const allowed = ['admin','superadmin']
    return this.checkAuthorization(user, allowed)
  }

  canUserView(user: any): boolean {
    const allowed = ['user']
    return this.checkAuthorization(user, allowed)
  }

  canSuperAdminView(user: any): boolean {
    const allowed = ['superadmin']
    return this.checkAuthorization(user, allowed)
  }

  // determines if user has matching role
  private checkAuthorization(user: any, allowedRoles: string[]): boolean {
    if (!user) return false
    for (const role of allowedRoles) {
      if (user.role[role]) {
        return true
      }
    }
    return false;
  }

}
