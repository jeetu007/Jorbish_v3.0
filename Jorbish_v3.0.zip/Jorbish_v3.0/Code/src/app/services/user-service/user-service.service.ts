import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { AuthService } from '../../services/auth/auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private afs: AngularFirestore, private authService: AuthService) { }

  getUsers(): Observable<any> {
    return new Observable((observer) => {
      let userList = this.afs.collection('users').get()
      userList.subscribe(snapShot => {
        let tempArr = [];
        snapShot.forEach(doc => {
          tempArr.push(doc.data())
        })
        observer.next(tempArr);
        observer.complete();
      })
    })
  }

  addUser(model, center_id) {

    if (center_id == undefined)
      center_id = ""
    return new Observable((observer) => {

      let id = this.afs.createId();
      const userObj = {
        uid: id,
        address: model.address,
        displayName: model.firstName + " " + model.lastName,
        email: model.email,
        role: model.role,
        center_ref: center_id
      }

      this.afs.collection('users').doc(id).set(userObj);
      let user = this.afs.collection('users').doc(id).get();

      if (user) {
        observer.next(true);
        observer.complete();
      } else {
        observer.error(false);
        observer.complete();
      }

    })
  }



  editUser(model, center_id) {
    if (center_id == undefined)
      center_id = ""
    return new Observable((observer) => {
      const userObj = {
        uid: model.uid,
        address: model.address,
        displayName: model.firstName + " " + model.lastName,
        email: model.email,
        role: model.role,
        center_ref: center_id
      }

      this.afs.collection('users').doc(model.uid).update(userObj);
      // set(userObj, { merge: true });
      let user = this.afs.collection('users').doc(model.uid).get();

      if (user) {
        observer.next(true);
        observer.complete();
      } else {
        observer.error(false);
        observer.complete();
      }

    })
  }

  delete(model) {
    this.afs.collection("users").doc(model.uid).delete();
  }

  getCenters(city) {
    return new Observable((observer) => {
      let centers = this.afs.collection("centers", ref => ref.where("address.city", "==", city)).get()
      centers.subscribe(snapshot => {
        //console.log(snapshot.docs)
        let centerArr = [];
        for (let center of snapshot.docs) {
          centerArr.push(center.data())
        }

        if (centerArr) {
          observer.next(centerArr);
          observer.complete();
        } else {
          observer.error(false);
          observer.complete();
        }

      })
    })
  }

  getAdminCenter(center_ref) {
    return new Observable((observer) => {
      let centers = this.afs.collection("centers").doc(center_ref).get()
      centers.subscribe(res => {
        if (res.data()) {
          observer.next(res.data());
          observer.complete();
        } else {
          observer.error(false);
          observer.complete();
        }
      })
    })
  }


  getCenterUsingCenterId(centerId) {
    return new Observable((observer) => {
      let centers = this.afs.collection("centers", ref => ref.where("centerId", "==", centerId)).get()
      centers.subscribe(snapshot => {
        let centerArr = [];
        for (let center of snapshot.docs) {
          centerArr.push(center.data())
        }

        if (centerArr) {
          observer.next(centerArr);
          observer.complete();
        } else {
          observer.error(false);
          observer.complete();
        }

      })
    })
  }

}
