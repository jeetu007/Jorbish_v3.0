import { TestBed, async, inject } from '@angular/core/testing';

import { SuperadminGuardGuard } from './superadmin-guard.guard';

describe('SuperadminGuardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SuperadminGuardGuard]
    });
  });

  it('should ...', inject([SuperadminGuardGuard], (guard: SuperadminGuardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
