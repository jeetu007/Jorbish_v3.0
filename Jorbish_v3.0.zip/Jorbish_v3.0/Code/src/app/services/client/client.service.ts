import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { ToastrService } from 'ngx-toastr';
import { Router } from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private ngFireStore: AngularFirestore,private toastr: ToastrService, private router : Router) { }
  bookingDetails: any;

  getClients() {
    this.ngFireStore.collection("clients").valueChanges().subscribe(res => {
      return res;
    }, err => {
      return (null);
    });
  }

  updateClient(selectedClient) {
    this.ngFireStore.collection("clients").doc(selectedClient.id).update(selectedClient)
      .then(res => {
        console.log("Updated...", res);
      })
      .catch(err => {
        console.log("Failed...", err);
      });
  }

  saveClient(clientId, clientData) {
    this.ngFireStore.collection("clients").doc(clientId).set(clientData).then(res => {
      console.log(res);
    }).catch(err => {
      console.log(err);
    });
  }

  saveBillingInfo(billingDetail) {
    let fireStoreId = this.ngFireStore.createId();
    billingDetail["billingId"] = fireStoreId;
    this.ngFireStore.collection("billing").doc(fireStoreId).set(billingDetail).then(res => {
      console.log(res);
    }).catch(err => {
      console.log(err);
    });
  }

  setBookingDetail(bookingDetail) {
    this.bookingDetails = bookingDetail;
  }

  getBookingDetail() {
    return this.bookingDetails;
  }
}
