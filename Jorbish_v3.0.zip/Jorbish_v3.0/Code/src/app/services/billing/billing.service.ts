import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';


@Injectable({
  providedIn: 'root'
})
export class BillingService {

  billingCollection : any;
  priceMasterCollection:any;
  billHistoryCollection: any;
  bookingDetails: any = {};

  constructor(private firestore: AngularFirestore) { 
    this.billingCollection = firestore.collection("billing");
    this.priceMasterCollection = firestore.collection("price_masters");
    this.billHistoryCollection = firestore.collection("billingHistory");
  }

  getPrice(priceId){
    return this.priceMasterCollection.doc(priceId).get();
  }

  saveBill(bill){
    let id = this.firestore.createId();
    return this.billingCollection.doc(id).set(bill);
  }

  getBill(){
    return this.billingCollection;
  }

  saveToBillHistory(bill){
    this.billHistoryCollection.add(bill).then(res => {
      console.log(res);      
    }).catch(err=>{
      console.log(err);     
    });
  }

  getPaytmTransaction(orderId) {
    return this.firestore.collection("paytm_transactions", ref => ref.where("ORDERID", "==",orderId)).get();
  }

  getBilling(orderId) {
    return this.firestore.collection("billing", ref => ref.where("billingId", "==",orderId)).get();
  }

  saveTransaction(transaction){
      this.firestore.collection("transaction_table").add(transaction).then(res => {
        console.log(res);        
      }).catch(err => {
        console.log(err);        
      })
  }

  updateBooking(bookingUpdate){
    this.firestore.collection("billing").doc(bookingUpdate.billingId).update(bookingUpdate).then(res => {
      console.log(res);      
    }).catch(err => {
      console.log(err);      
    });
  }

  billingHistroy(histroy){
    console.log('Histroy Object ==>',histroy);
    let id = this.firestore.createId();
    histroy["billingHistoryId"] = id;
   return this.firestore.collection("billingHistory").doc(id).set(histroy,{merge:true});
  }
}
