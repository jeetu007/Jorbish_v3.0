import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { TagInputModule } from 'ngx-chips';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { NgxTypeaheadModule } from 'ngx-typeahead';
import { WebcamModule } from 'ngx-webcam';
import { ToastrModule } from 'ngx-toastr';

import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFireStorageModule } from '@angular/fire/storage';

import { ClientComponent } from './components/client/client.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { AdminComponent } from './components/admin/admin.component';
import { AccessDeniedComponent } from './components/access-denied/access-denied.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { UserOperationComponent } from './components/user-operation/user-operation.component';
import { SuperadminComponent } from './components/superadmin/superadmin.component';
import { BillingComponent } from './components/billing/billing.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { BookCenterComponent } from './components/book-center/book-center.component';
import { AddClientComponent } from './components/add-client/add-client.component';
import { BookingDetailsComponent } from './components/booking-details/booking-details.component';
import { BillingHistroyComponent } from './components/billing-histroy/billing-histroy.component';
import { PaymentStatusComponent } from './components/payment-status/payment-status.component';

import {NgxPaginationModule} from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    ClientComponent,
    LoginComponent,
    RegistrationComponent,
    AdminComponent,
    AccessDeniedComponent,
    PageNotFoundComponent,
    UserOperationComponent,
    SuperadminComponent,
    BillingComponent,
    AddUserComponent,
    BookCenterComponent,
    AddClientComponent,
    BookingDetailsComponent,
    BillingHistroyComponent,
    PaymentStatusComponent
  ],
  imports: [
    BrowserModule, BrowserAnimationsModule, NgxTypeaheadModule, TagInputModule,
    AppRoutingModule, FormsModule, AngularFontAwesomeModule, ReactiveFormsModule,
    AngularFireModule.initializeApp(environment.firebase), WebcamModule, ToastrModule.forRoot(),
    AngularFirestoreModule, AngularFireAuthModule, AngularFireStorageModule, NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
