import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientComponent } from './components/client/client.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { AdminComponent } from './components/admin/admin.component';
import { AccessDeniedComponent } from './components/access-denied/access-denied.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { AddClientComponent } from './components/add-client/add-client.component';
import { AdminGuard } from './guards/admin/admin.guard';
import { UserGuard } from './guards/user/user.guard';
import { SuperadminGuard } from './guards/super-admin/superadmin.guard';

import { UserOperationComponent } from "./components/user-operation/user-operation.component";
import { SuperadminComponent } from "./components/superadmin/superadmin.component";
import { BillingComponent } from "./components/billing/billing.component";
import { BillingHistroyComponent } from './components/billing-histroy/billing-histroy.component';
import { BookingDetailsComponent } from "./components/booking-details/booking-details.component";

import { BookCenterComponent } from './components/book-center/book-center.component';
import { PaymentStatusComponent } from "./components/payment-status/payment-status.component";

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'add-client/:centerId', component: AddClientComponent },
  { path: 'client', component: ClientComponent, canActivate : [UserGuard] },
  { path: 'admin', component: AdminComponent, canActivate : [AdminGuard] },
  { path: 'user-operation', component: UserOperationComponent },
  { path: 'superadmin', component: SuperadminComponent, canActivate : [SuperadminGuard] },
  { path: 'billing/:orderId', component: BillingComponent, canActivate : [AdminGuard] },
  { path: 'book-center', component: BookCenterComponent, canActivate : [UserGuard] },
  { path: 'access-denied', component: AccessDeniedComponent },
  { path: 'booking-details', component: BookingDetailsComponent, canActivate : [AdminGuard] },
  { path: 'booking-histroy', component: BillingHistroyComponent, canActivate : [AdminGuard] },
  { path: 'payment-status/:orderId', component: PaymentStatusComponent, canActivate : [AdminGuard] },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
