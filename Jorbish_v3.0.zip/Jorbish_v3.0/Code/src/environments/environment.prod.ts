export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyCchrhfJJWo7VtcKg5fgzH4mQGcmwcdvN0",
    authDomain: "jorbish-58ca9.firebaseapp.com",
    databaseURL: "https://jorbish-58ca9.firebaseio.com",
    projectId: "jorbish-58ca9",
    storageBucket: "jorbish-58ca9.appspot.com",
    messagingSenderId: "99688662221"
  }
};
